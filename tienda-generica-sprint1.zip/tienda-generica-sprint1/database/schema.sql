-- ==========================================================
-- Tienda Generica - Sprint 1
-- Script de creacion de base de datos (MySQL 8.0.24)
-- ==========================================================
-- Nota: si se deja spring.jpa.hibernate.ddl-auto=update en
-- application.properties, Spring Boot crea esta tabla solo.
-- Este script se deja como respaldo / para MySQL Workbench.
-- ==========================================================

CREATE DATABASE IF NOT EXISTS tienda_generica
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE tienda_generica;

CREATE TABLE IF NOT EXISTS usuarios (
    cedula_usuario  BIGINT       NOT NULL,
    nombre_usuario  VARCHAR(150) NOT NULL,
    email_usuario   VARCHAR(150) NOT NULL,
    usuario         VARCHAR(50)  NOT NULL,
    password        VARCHAR(255) NOT NULL,
    PRIMARY KEY (cedula_usuario),
    UNIQUE KEY uk_usuarios_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Usuario por defecto exigido por la especificacion funcional:
--   usuario:    admininicial
--   contraseña: admin123456   (guardada cifrada con BCrypt)
--
-- El hash de abajo corresponde a "admin123456". Si prefieres que la
-- aplicacion lo cree automaticamente, no ejecutes este INSERT: la
-- clase DataInitializer lo hace al levantar el servidor si no existe.
INSERT INTO usuarios (cedula_usuario, nombre_usuario, email_usuario, usuario, password)
SELECT 1000000000, 'Administrador Inicial', 'admin@tiendagenerica.com', 'admininicial',
       '$2a$10$t6NlMOYYmfBHzVt.Ut28aeIa3WrlpT83GQwSVxeDaNuhCR8xqHu36'
WHERE NOT EXISTS (
    SELECT 1 FROM usuarios WHERE usuario = 'admininicial'
);
