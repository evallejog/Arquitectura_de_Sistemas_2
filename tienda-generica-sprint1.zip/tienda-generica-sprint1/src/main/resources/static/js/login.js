const form = document.getElementById('loginForm');
const alertBox = document.getElementById('alertBox');
const btnCancelar = document.getElementById('btnCancelar');

function mostrarError(mensaje) {
    alertBox.textContent = mensaje;
    alertBox.classList.remove('hidden');
    alertBox.classList.add('error');
}

function limpiarAlerta() {
    alertBox.classList.add('hidden');
    alertBox.textContent = '';
}

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    limpiarAlerta();

    const usuario = document.getElementById('usuario').value.trim();
    const password = document.getElementById('password').value;

    try {
        const resp = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ usuario, password })
        });

        const data = await resp.json();

        if (!resp.ok) {
            // SP1-QA-2: usuario o contraseña errados
            mostrarError(data.mensaje || 'usuario o contraseña errados, intente de nuevo');
            return;
        }

        // SP1-QA-1: ingreso correcto -> ir al menu general
        sessionStorage.setItem('usuarioActual', JSON.stringify(data));
        window.location.href = 'index.html';

    } catch (err) {
        mostrarError('No fue posible conectar con el servidor. Intente de nuevo.');
    }
});

btnCancelar.addEventListener('click', () => {
    form.reset();
    limpiarAlerta();
});
