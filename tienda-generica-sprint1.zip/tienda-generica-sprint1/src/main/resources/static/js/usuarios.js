// Guard de sesion: si no hay login previo, se envia a la pantalla de login.
const sesion = JSON.parse(sessionStorage.getItem('usuarioActual') || 'null');
if (!sesion) {
    window.location.href = 'login.html';
}

const alertBox = document.getElementById('alertBox');

const cedulaInput = document.getElementById('cedula');
const nombreInput = document.getElementById('nombreCompleto');
const correoInput = document.getElementById('correo');
const usuarioInput = document.getElementById('usuario');
const passwordInput = document.getElementById('password');
const tablaBody = document.getElementById('tablaUsuarios');

function mostrarMensaje(mensaje, tipo) {
    alertBox.textContent = mensaje;
    alertBox.className = 'alert ' + tipo;
}

function limpiarFormulario() {
    cedulaInput.value = '';
    nombreInput.value = '';
    correoInput.value = '';
    usuarioInput.value = '';
    passwordInput.value = '';
}

function leerFormulario() {
    return {
        cedula_usuario: cedulaInput.value ? Number(cedulaInput.value) : null,
        nombre_usuario: nombreInput.value.trim(),
        email_usuario: correoInput.value.trim(),
        usuario: usuarioInput.value.trim(),
        password: passwordInput.value
    };
}

async function cargarTabla() {
    try {
        const resp = await fetch('/usuarios/listar');
        const usuarios = await resp.json();
        tablaBody.innerHTML = '';
        usuarios.forEach(u => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${u.cedula_usuario}</td>
                <td>${u.nombre_usuario}</td>
                <td>${u.email_usuario}</td>
                <td>${u.usuario}</td>
            `;
            tr.addEventListener('click', () => {
                cedulaInput.value = u.cedula_usuario;
                nombreInput.value = u.nombre_usuario;
                correoInput.value = u.email_usuario;
                usuarioInput.value = u.usuario;
                passwordInput.value = '';
            });
            tablaBody.appendChild(tr);
        });
    } catch (err) {
        mostrarMensaje('No fue posible cargar la lista de usuarios.', 'error');
    }
}

// SP1-QA-5 / SP1-QA-6: Consultar usuario por cedula
document.getElementById('btnConsultar').addEventListener('click', async () => {
    if (!cedulaInput.value) {
        mostrarMensaje('Escriba la cédula del usuario a consultar.', 'error');
        return;
    }
    try {
        const resp = await fetch(`/usuarios/consultar/${cedulaInput.value}`);
        const data = await resp.json();

        if (!resp.ok) {
            mostrarMensaje(data.mensaje || 'Usuario Inexistente', 'error');
            limpiarFormulario();
            return;
        }

        nombreInput.value = data.nombre_usuario;
        correoInput.value = data.email_usuario;
        usuarioInput.value = data.usuario;
        passwordInput.value = '';
        mostrarMensaje('Usuario encontrado.', 'success');
    } catch (err) {
        mostrarMensaje('Error de conexión al consultar el usuario.', 'error');
    }
});

// SP1-QA-3 / SP1-QA-4: Crear nuevo usuario
document.getElementById('btnCrear').addEventListener('click', async () => {
    try {
        const resp = await fetch('/usuarios/guardar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(leerFormulario())
        });
        const data = await resp.json();

        if (!resp.ok) {
            mostrarMensaje(data.mensaje || 'Faltan datos del usuario', 'error');
            limpiarFormulario();
            return;
        }

        mostrarMensaje(data.mensaje || 'Usuario Creado', 'success');
        limpiarFormulario();
        cargarTabla();
    } catch (err) {
        mostrarMensaje('Error de conexión al crear el usuario.', 'error');
    }
});

// SP1-QA-7 / SP1-QA-8: Actualizar datos de usuario
document.getElementById('btnActualizar').addEventListener('click', async () => {
    try {
        const resp = await fetch('/usuarios/actualizar', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(leerFormulario())
        });
        const data = await resp.json();

        if (!resp.ok) {
            mostrarMensaje(data.mensaje || 'Datos faltantes', 'error');
            limpiarFormulario();
            return;
        }

        mostrarMensaje(data.mensaje || 'Datos del Usuario Actualizados', 'success');
        limpiarFormulario();
        cargarTabla();
    } catch (err) {
        mostrarMensaje('Error de conexión al actualizar el usuario.', 'error');
    }
});

// SP1-QA-9 / SP1-QA-10: Borrar usuario
document.getElementById('btnBorrar').addEventListener('click', async () => {
    if (!cedulaInput.value) {
        mostrarMensaje('Cédula Errada', 'error');
        return;
    }
    try {
        const resp = await fetch(`/usuarios/eliminar/${cedulaInput.value}`, {
            method: 'DELETE'
        });
        const data = await resp.json();

        if (!resp.ok) {
            mostrarMensaje(data.mensaje || 'Cédula Errada', 'error');
            limpiarFormulario();
            return;
        }

        mostrarMensaje(data.mensaje || 'Datos del Usuario Borrados', 'success');
        limpiarFormulario();
        cargarTabla();
    } catch (err) {
        mostrarMensaje('Error de conexión al borrar el usuario.', 'error');
    }
});

document.getElementById('btnLimpiar').addEventListener('click', () => {
    limpiarFormulario();
    alertBox.className = 'alert hidden';
});

cargarTabla();
