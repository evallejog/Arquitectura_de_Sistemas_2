package com.tiendagenerica.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class AppConfig implements WebMvcConfigurer {

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * CORS abierto para /api/** y /usuarios/**: util si en un futuro Sprint
     * el frontend se sirve desde otro origen (ej. servidor de desarrollo
     * separado). Mientras el frontend viva en src/main/resources/static,
     * esto no es estrictamente necesario, pero no estorba.
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**").allowedOrigins("*").allowedMethods("*");
        registry.addMapping("/usuarios/**").allowedOrigins("*").allowedMethods("*");
    }
}
