package com.tiendagenerica.config;

import com.tiendagenerica.model.Usuario;
import com.tiendagenerica.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Garantiza que exista el usuario por defecto exigido por la
 * especificacion funcional:
 *   usuario:    admininicial
 *   contraseña: admin123456
 *
 * Se ejecuta una sola vez al levantar la aplicacion (idempotente).
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private static final Long CEDULA_ADMIN_INICIAL = 1000000000L;
    private static final String USUARIO_ADMIN_INICIAL = "admininicial";
    private static final String PASSWORD_ADMIN_INICIAL = "admin123456";

    private final UsuarioRepository usuarioRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public DataInitializer(UsuarioRepository usuarioRepository, BCryptPasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (!usuarioRepository.existsByUsuarioIgnoreCase(USUARIO_ADMIN_INICIAL)) {
            Usuario admin = new Usuario(
                    CEDULA_ADMIN_INICIAL,
                    "Administrador Inicial",
                    "admin@tiendagenerica.com",
                    USUARIO_ADMIN_INICIAL,
                    passwordEncoder.encode(PASSWORD_ADMIN_INICIAL)
            );
            usuarioRepository.save(admin);
            System.out.println(">> Usuario por defecto 'admininicial' creado correctamente.");
        }
    }
}
