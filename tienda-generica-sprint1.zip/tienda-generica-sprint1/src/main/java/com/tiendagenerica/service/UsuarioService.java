package com.tiendagenerica.service;

import com.tiendagenerica.dto.UsuarioDTO;
import com.tiendagenerica.exception.DatosFaltantesException;
import com.tiendagenerica.exception.RecursoDuplicadoException;
import com.tiendagenerica.exception.RecursoNoEncontradoException;
import com.tiendagenerica.model.Usuario;
import com.tiendagenerica.repository.UsuarioRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * MODULO DE GESTION DE USUARIOS (HU-002 a HU-005).
 *
 * Cubre el conjunto de pruebas del Sprint 1:
 *  - SP1-QA-3 / SP1-QA-4: creacion de usuario (correcta / con datos faltantes).
 *  - SP1-QA-5 / SP1-QA-6: consulta por cedula (existente / inexistente).
 *  - SP1-QA-7 / SP1-QA-8: actualizacion (correcta / con datos en blanco).
 *  - SP1-QA-9 / SP1-QA-10: borrado (correcto / con cedula errada).
 */
@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public UsuarioService(UsuarioRepository usuarioRepository, BCryptPasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<Usuario> listar() {
        return usuarioRepository.findAll();
    }

    /** HU-003 / SP1-QA-5 / SP1-QA-6: consultar usuario por cedula. */
    public Usuario consultarPorCedula(Long cedula) {
        return usuarioRepository.findById(cedula)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario Inexistente"));
    }

    /** HU-002 / SP1-QA-3 / SP1-QA-4: crear un nuevo usuario. */
    public Usuario crear(UsuarioDTO dto) {
        validarCompletitud(dto, true, "Faltan datos del usuario");

        if (usuarioRepository.existsById(dto.getCedulaUsuario())) {
            throw new RecursoDuplicadoException("Ya existe un usuario con esa cédula");
        }
        if (usuarioRepository.existsByUsuarioIgnoreCase(dto.getUsuario())) {
            throw new RecursoDuplicadoException("Ya existe ese nombre de usuario");
        }

        Usuario usuario = new Usuario(
                dto.getCedulaUsuario(),
                dto.getNombreUsuario().trim(),
                dto.getEmailUsuario().trim(),
                dto.getUsuario().trim(),
                passwordEncoder.encode(dto.getPassword())
        );
        return usuarioRepository.save(usuario);
    }

    /** HU-004 / SP1-QA-7 / SP1-QA-8: actualizar datos de un usuario existente. */
    public Usuario actualizar(UsuarioDTO dto) {
        validarCompletitud(dto, true, "Datos faltantes");

        Usuario existente = usuarioRepository.findById(dto.getCedulaUsuario())
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario Inexistente"));

        existente.setNombreUsuario(dto.getNombreUsuario().trim());
        existente.setEmailUsuario(dto.getEmailUsuario().trim());
        existente.setUsuario(dto.getUsuario().trim());
        existente.setPassword(passwordEncoder.encode(dto.getPassword()));

        return usuarioRepository.save(existente);
    }

    /** HU-005 / SP1-QA-9 / SP1-QA-10: borrar un usuario por cedula. */
    public void borrar(Long cedula) {
        if (cedula == null) {
            throw new DatosFaltantesException("Cédula Errada");
        }
        if (!usuarioRepository.existsById(cedula)) {
            throw new RecursoNoEncontradoException("Cédula Errada");
        }
        usuarioRepository.deleteById(cedula);
    }

    /**
     * Valida que ningun campo obligatorio venga nulo o en blanco.
     * El mensaje difiere segun la operacion, tal como exige el
     * conjunto de pruebas: "Faltan datos del usuario" al crear (SP1-QA-4)
     * y "Datos faltantes" al actualizar (SP1-QA-8).
     */
    private void validarCompletitud(UsuarioDTO dto, boolean exigirPassword, String mensajeError) {
        boolean faltan = dto == null
                || dto.getCedulaUsuario() == null
                || isBlank(dto.getNombreUsuario())
                || isBlank(dto.getEmailUsuario())
                || isBlank(dto.getUsuario())
                || (exigirPassword && isBlank(dto.getPassword()));

        if (faltan) {
            throw new DatosFaltantesException(mensajeError);
        }
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
