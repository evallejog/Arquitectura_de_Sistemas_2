package com.tiendagenerica.service;

import com.tiendagenerica.dto.LoginRequest;
import com.tiendagenerica.exception.CredencialesInvalidasException;
import com.tiendagenerica.model.Usuario;
import com.tiendagenerica.repository.UsuarioRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * MODULO DE LOGIN DEL SISTEMA (HU-001).
 *
 * Valida usuario y contraseña contra la tabla "usuarios".
 * Cubre:
 *  - SP1-QA-1: ingreso correcto (admininicial u otro usuario creado).
 *  - SP1-QA-2: ingreso incorrecto -> "usuario o contraseña errados, intente de nuevo".
 */
@Service
public class AuthService {

    private static final String MSG_CREDENCIALES_INVALIDAS =
            "usuario o contraseña errados, intente de nuevo";

    private final UsuarioRepository usuarioRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public AuthService(UsuarioRepository usuarioRepository, BCryptPasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public Usuario login(LoginRequest request) {
        if (request.getUsuario() == null || request.getUsuario().isBlank()
                || request.getPassword() == null || request.getPassword().isBlank()) {
            throw new CredencialesInvalidasException(MSG_CREDENCIALES_INVALIDAS);
        }

        Usuario usuario = usuarioRepository.findByUsuarioIgnoreCase(request.getUsuario().trim())
                .orElseThrow(() -> new CredencialesInvalidasException(MSG_CREDENCIALES_INVALIDAS));

        if (!passwordEncoder.matches(request.getPassword(), usuario.getPassword())) {
            throw new CredencialesInvalidasException(MSG_CREDENCIALES_INVALIDAS);
        }

        return usuario;
    }
}
