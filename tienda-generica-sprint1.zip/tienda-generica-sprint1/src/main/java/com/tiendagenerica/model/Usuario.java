package com.tiendagenerica.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entidad que representa la tabla "usuarios" segun la especificacion
 * funcional del Sprint 1:
 *   cedula, nombre completo, correo electronico, usuario, contraseña.
 */
@Entity
@Table(name = "usuarios")
public class Usuario {

    /** Cedula del usuario. Es la llave primaria (usada como "id" en la API). */
    @Id
    @Column(name = "cedula_usuario")
    private Long cedulaUsuario;

    @Column(name = "nombre_usuario", nullable = false, length = 150)
    private String nombreUsuario;

    @Column(name = "email_usuario", nullable = false, length = 150)
    private String emailUsuario;

    @Column(name = "usuario", nullable = false, unique = true, length = 50)
    private String usuario;

    /** Contraseña almacenada siempre cifrada (BCrypt). */
    @Column(name = "password", nullable = false, length = 255)
    private String password;

    public Usuario() {
    }

    public Usuario(Long cedulaUsuario, String nombreUsuario, String emailUsuario,
                   String usuario, String password) {
        this.cedulaUsuario = cedulaUsuario;
        this.nombreUsuario = nombreUsuario;
        this.emailUsuario = emailUsuario;
        this.usuario = usuario;
        this.password = password;
    }

    public Long getCedulaUsuario() {
        return cedulaUsuario;
    }

    public void setCedulaUsuario(Long cedulaUsuario) {
        this.cedulaUsuario = cedulaUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getEmailUsuario() {
        return emailUsuario;
    }

    public void setEmailUsuario(String emailUsuario) {
        this.emailUsuario = emailUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
