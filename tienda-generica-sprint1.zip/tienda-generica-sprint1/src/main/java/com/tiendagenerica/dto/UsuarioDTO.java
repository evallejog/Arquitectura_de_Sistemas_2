package com.tiendagenerica.dto;

/**
 * DTO usado para crear/actualizar/listar usuarios via API.
 * Coincide con el contrato mostrado en la especificacion de API:
 * { "cedula_usuario", "email_usuario", "nombre_usuario", "password", "usuario" }
 */
public class UsuarioDTO {

    private Long cedulaUsuario;
    private String nombreUsuario;
    private String emailUsuario;
    private String usuario;
    private String password;

    public UsuarioDTO() {
    }

    public UsuarioDTO(Long cedulaUsuario, String nombreUsuario, String emailUsuario,
                       String usuario, String password) {
        this.cedulaUsuario = cedulaUsuario;
        this.nombreUsuario = nombreUsuario;
        this.emailUsuario = emailUsuario;
        this.usuario = usuario;
        this.password = password;
    }

    public Long getCedulaUsuario() {
        return cedulaUsuario;
    }

    public void setCedulaUsuario(Long cedulaUsuario) {
        this.cedulaUsuario = cedulaUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getEmailUsuario() {
        return emailUsuario;
    }

    public void setEmailUsuario(String emailUsuario) {
        this.emailUsuario = emailUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
