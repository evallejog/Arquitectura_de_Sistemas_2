package com.tiendagenerica.dto;

/**
 * Respuesta simple usada para los mensajes de informacion/error
 * exigidos en el Conjunto de Pruebas del Sprint 1
 * (ej: "Usuario Creado", "Usuario Inexistente", "Cédula Errada", etc).
 */
public class MensajeResponse {

    private String mensaje;

    public MensajeResponse() {
    }

    public MensajeResponse(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
