package com.tiendagenerica.exception;

/** Se lanza cuando el usuario y/o contraseña del login no coinciden. */
public class CredencialesInvalidasException extends RuntimeException {
    public CredencialesInvalidasException(String mensaje) {
        super(mensaje);
    }
}
