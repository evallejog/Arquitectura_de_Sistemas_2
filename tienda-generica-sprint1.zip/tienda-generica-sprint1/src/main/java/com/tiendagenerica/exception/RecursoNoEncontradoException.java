package com.tiendagenerica.exception;

/** Se lanza cuando se consulta/actualiza/borra una cedula que no existe. */
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
