package com.tiendagenerica.exception;

/** Se lanza cuando falta o llega en blanco algun campo obligatorio. */
public class DatosFaltantesException extends RuntimeException {
    public DatosFaltantesException(String mensaje) {
        super(mensaje);
    }
}
