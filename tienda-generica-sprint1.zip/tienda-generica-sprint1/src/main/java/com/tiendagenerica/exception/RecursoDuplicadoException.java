package com.tiendagenerica.exception;

/** Se lanza cuando ya existe un usuario con la misma cedula o el mismo username. */
public class RecursoDuplicadoException extends RuntimeException {
    public RecursoDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
