package com.tiendagenerica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada de la aplicacion.
 * Sprint 1: Modulo de Login del Sistema + Modulo de Gestion de Usuarios.
 */
@SpringBootApplication
public class TiendaGenericaApplication {

    public static void main(String[] args) {
        SpringApplication.run(TiendaGenericaApplication.class, args);
    }
}
