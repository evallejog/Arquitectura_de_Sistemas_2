package com.tiendagenerica.controller;

import com.tiendagenerica.dto.MensajeResponse;
import com.tiendagenerica.dto.UsuarioDTO;
import com.tiendagenerica.model.Usuario;
import com.tiendagenerica.service.UsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * MODULO DE GESTION DE USUARIOS.
 *
 * Contrato de API tal como aparece en la especificacion del documento
 * ("Especificacion de la API... APIs de Usuarios"):
 *   GET    /usuarios/listar
 *   POST   /usuarios/guardar
 *   PUT    /usuarios/actualizar
 *   DELETE /usuarios/eliminar/{id}
 *
 * Se agrega ademas GET /usuarios/consultar/{cedula} para cubrir HU-003
 * (consulta de un usuario por cedula) y el boton "Consultar" del mockup.
 */
@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    /** GET /usuarios/listar */
    @GetMapping("/listar")
    public ResponseEntity<List<UsuarioDTO>> listar() {
        List<UsuarioDTO> resultado = usuarioService.listar().stream()
                .map(this::toDtoSinPassword)
                .collect(Collectors.toList());
        return ResponseEntity.ok(resultado);
    }

    /** GET /usuarios/consultar/{cedula}  (HU-003 / SP1-QA-5 / SP1-QA-6) */
    @GetMapping("/consultar/{cedula}")
    public ResponseEntity<UsuarioDTO> consultar(@PathVariable Long cedula) {
        Usuario usuario = usuarioService.consultarPorCedula(cedula);
        return ResponseEntity.ok(toDtoSinPassword(usuario));
    }

    /** POST /usuarios/guardar  (HU-002 / SP1-QA-3 / SP1-QA-4) */
    @PostMapping("/guardar")
    public ResponseEntity<MensajeResponse> guardar(@RequestBody UsuarioDTO dto) {
        usuarioService.crear(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new MensajeResponse("Usuario Creado"));
    }

    /** PUT /usuarios/actualizar  (HU-004 / SP1-QA-7 / SP1-QA-8) */
    @PutMapping("/actualizar")
    public ResponseEntity<MensajeResponse> actualizar(@RequestBody UsuarioDTO dto) {
        usuarioService.actualizar(dto);
        return ResponseEntity.ok(new MensajeResponse("Datos del Usuario Actualizados"));
    }

    /** DELETE /usuarios/eliminar/{id}  (HU-005 / SP1-QA-9 / SP1-QA-10) */
    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<MensajeResponse> eliminar(@PathVariable Long id) {
        usuarioService.borrar(id);
        return ResponseEntity.ok(new MensajeResponse("Datos del Usuario Borrados"));
    }

    private UsuarioDTO toDtoSinPassword(Usuario usuario) {
        return new UsuarioDTO(
                usuario.getCedulaUsuario(),
                usuario.getNombreUsuario(),
                usuario.getEmailUsuario(),
                usuario.getUsuario(),
                null
        );
    }
}
