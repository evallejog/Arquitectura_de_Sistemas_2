package com.tiendagenerica.controller;

import com.tiendagenerica.dto.LoginRequest;
import com.tiendagenerica.model.Usuario;
import com.tiendagenerica.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * MODULO DE LOGIN DEL SISTEMA.
 * HU-001: ingreso al sistema con el usuario inicial admininicial / admin123456.
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest request) {
        Usuario usuario = authService.login(request);

        Map<String, Object> body = new HashMap<>();
        body.put("mensaje", "Ingreso exitoso");
        body.put("cedula_usuario", usuario.getCedulaUsuario());
        body.put("nombre_usuario", usuario.getNombreUsuario());
        body.put("usuario", usuario.getUsuario());

        return ResponseEntity.ok(body);
    }
}
